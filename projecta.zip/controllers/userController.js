const db = require('../db/mysqlConfig');

const getUser = (req,res)=>{
    // var userRecord = [
    //     {id:1 , name:"Akshay" ,age:20},
    //     {id:2 , name:"Ajay" ,age:21},
    //     {id:3 , name:"Aniket" ,age:22}
    // ];


    // res.send("get Route Called");
    
    //lets get values from database mysql
    db.dbConnect().query('SELECT * from userinfo' , (error,results)=>{
        if(error){
            console.log(error);
            process.exit(1);
        }
        else{
            // console.log(results);
            res.send({msg:results});

        }
    });
}

const insertUser = (req,res)=>{
    //https://expressjs.com/en/5x/api.html#req.body
    console.log(req.body); //undefined
    var username = req.body.name; //received values from textbox
    var userage = req.body.age; //received values from textbox

    var insert_query = `insert into userinfo (name,age) values ('${username}','${userage}') `;

    db.dbConnect().query(insert_query , (error,results)=>{
        if(error){
            console.log(error);
            process.exit(1);
        }
        else{
            // console.log(results);
            res.send({msg:"Record Added in DB"});
        }
    });
}

module.exports ={
    getUser,
    insertUser
}