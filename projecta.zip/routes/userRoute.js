const express = require('express');
//https://expressjs.com/en/guide/routing.html

//connect ur controllers with routes
const userC = require('../controllers/userController');
// import *  from '../controllers/userController';

const router = express.Router();


router
.get('/',userC.getUser)
.post('/',userC.insertUser);

module.exports = router;

// CRUD