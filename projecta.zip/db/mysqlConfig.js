// npm install mysql
//https://www.npmjs.com/package/mysql
var mysql = require('mysql');
const dbConnect = ()=>{
  
    var connection = mysql.createConnection({
        host     : process.env.HOSTDB,
        user     : process.env.DBUSER,
        password : process.env.DBPASS,
        database : process.env.USERDB
    });
    return connection;
}

module.exports = {
    dbConnect
}

/*
    CREATE table userinfo(
        id int AUTO_INCREMENT primary key,
        name varchar(100),
        age int
    );
*/