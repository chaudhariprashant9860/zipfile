// console.log('test')
//https://www.npmjs.com/package/dotenv
require('dotenv').config();

// console.log(process);

//https://www.npmjs.com/package/express
const express = require('express');
const bodyParser = require('body-parser');

var db = require('./db/mysqlConfig');
const ans_db_connect = db.dbConnect();
// console.log(ans_db_connect);
ans_db_connect.connect();

//database mysql database -- hostname,user,password ,database

const userR = require('./routes/userRoute');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use('/api/users' , userR);
//http://localhost:4000/api/users (GET,POST,PUT,DELETE)

//creating first route
// app.get('/' , (req,res)=>{
//     res.send("<h1> test </h1>");
// });

app.listen(process.env.PORT , ()=>{
    console.log('SERVER RUNNING');
});