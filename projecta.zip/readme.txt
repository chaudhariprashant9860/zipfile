npm i express dotenv body-parser

Q: why body-parser required?
Ans :
every form is having : enctype="application/x-www-form-urlencoded"

to parse incoming request u have to use 
req.body ( default value is undefined)

to solve thisissue use:

npm i body-parser

and 

use this function :
app.use(bodyParser.urlencoded({ extended: true }));


Q: req.body ????

Ans: req(object).body(property) will help us to receive incoming request (data) from any client


Q:app.use(bodyParser.urlencoded({ extended: true })); ??
Ans: This is will help us to parse incoming data from your form tag

Q:app.use(bodyParser.json());??
Ans: This is will help us to parse incoming data as a JSON String